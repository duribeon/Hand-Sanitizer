//Desired number of hours to sleep
var SleepGoal = 8;

//Desired number of daily steps
var WalkGoal = 8000;

//Language selection
//<EMPTY> - Use language setting from Android application
//en_EN - English
//ru_RU - Russian
//fr_FR - French
//es_ES - Spanish
//de_DE - German
var lang = "";
