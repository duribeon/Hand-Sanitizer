# TAS

## OCEAN IoT Platform - various sensor interworking

### Arduino
Dust sensor : PM1001
Temperature-Humidity sensor : DHT11

### Other
Camera module : NoIR Camera V2
CO_2 sensor
Beacon : RECO beacon
